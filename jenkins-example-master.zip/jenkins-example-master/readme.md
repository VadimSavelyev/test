# Jenkins Example <img src="https://raw.github.com/strongloop-community/jenkins-example/master/fake-status-icon.png" width="106px"/>

Roll your own Node CI server with Jenkins!  See the accompanying [blog](http://strongloop.com/strongblog/roll-your-own-node-js-ci-server-with-jenkins-part-1/) [posts](http://strongloop.com/strongblog/roll-your-own-node-js-ci-server-with-jenkins-part-2/) for more information on this repository.
